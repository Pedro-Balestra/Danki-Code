import 'package:flutter/material.dart';

AppBar wAppBar() {
  return AppBar(
    title: const Text(
      "Racha Conta",
      style: TextStyle(color: Colors.white),
    ),
    centerTitle: true,
    backgroundColor: const Color(0xffff6600),
  );
}
